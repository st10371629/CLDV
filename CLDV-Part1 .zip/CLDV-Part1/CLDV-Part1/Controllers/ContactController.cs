﻿using Microsoft.AspNetCore.Mvc;

namespace CLDV_Part1.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
