﻿using Microsoft.AspNetCore.Mvc;

namespace CLDV_Part1.Controllers
{
    public class WorkController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
